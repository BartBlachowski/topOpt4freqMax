function gate = a4_validate_frozen_identity(arm, topologyCsvPath)
%A4_VALIDATE_FROZEN_IDENTITY  Specification-faithful V-P2-2 validator.
%
% Exact scalar identity and topology-file identity are separate invariants.
% Comparing the full-precision in-memory topology with a reload of a CSV
% written at 15 significant digits is only a numerical diagnostic and never
% contributes to the stop decision.

expected = struct( ...
    'omega1_tracked', 159.56562699328325, ...
    'final_design_change', 3.034903639330122e-03, ...
    'iterations', 2000, ...
    'mode_index_jstar', 1, ...
    'mac_to_phi0', 0.9996284251363903, ...
    'omega1_omega2_gap', 67.37267502573462);
expectedTopologySha256 = ...
    '9c3d961bcdf731cf413f0be7d4999b121acffea31d9e11356cb67d4b3f269806';

gate = struct( ...
    'pass', true, ...
    'failures', {{}}, ...
    'expected_scalars', expected, ...
    'scalar_identity', struct(), ...
    'exact_scalar_identity', true, ...
    'topology_csv_path', topologyCsvPath, ...
    'expected_topology_sha256', expectedTopologySha256, ...
    'actual_topology_sha256', '', ...
    'topology_file_identity', false, ...
    'numerical_diagnostics', localBlankDiagnostics());

names = fieldnames(expected);
for i = 1:numel(names)
    name = names{i};
    present = isfield(arm, name);
    actual = NaN;
    if present, actual = arm.(name); end
    identical = present && isequal(actual, expected.(name));
    gate.scalar_identity.(name) = identical;
    if ~identical
        gate.exact_scalar_identity = false;
        gate.pass = false;
        gate.failures{end+1} = sprintf('%s expected %.17g got %.17g', ...
            name, expected.(name), actual); %#ok<AGROW>
    end
end

if isfile(topologyCsvPath)
    gate.actual_topology_sha256 = localSha256File(topologyCsvPath);
    gate.topology_file_identity = ...
        strcmp(gate.actual_topology_sha256, expectedTopologySha256);
    gate.numerical_diagnostics = localCsvReloadDiagnostics(arm, topologyCsvPath);
else
    gate.actual_topology_sha256 = '<missing>';
end

if ~gate.topology_file_identity
    gate.pass = false;
    gate.failures{end+1} = sprintf( ...
        'topology CSV SHA-256 expected %s got %s', ...
        expectedTopologySha256, gate.actual_topology_sha256); %#ok<AGROW>
end
end

function diagnostics = localBlankDiagnostics()
diagnostics = struct( ...
    'decision_role', 'non-blocking', ...
    'comparison', 'full-precision in-memory topology versus CSV reload', ...
    'csv_reload_exactly_equals_in_memory', false, ...
    'same_number_of_values', false, ...
    'n_values', 0, ...
    'n_different_values', 0, ...
    'max_abs_difference', NaN);
end

function diagnostics = localCsvReloadDiagnostics(arm, path)
diagnostics = localBlankDiagnostics();
if ~isfield(arm, 'topology') || isempty(arm.topology), return; end

reloaded = readmatrix(path);
inMemory = arm.topology(:);
reloaded = reloaded(:);
diagnostics.n_values = numel(inMemory);
diagnostics.same_number_of_values = numel(inMemory) == numel(reloaded);
if ~diagnostics.same_number_of_values, return; end

diagnostics.csv_reload_exactly_equals_in_memory = isequal(inMemory, reloaded);
different = inMemory ~= reloaded;
diagnostics.n_different_values = sum(different);
if isempty(inMemory)
    diagnostics.max_abs_difference = 0;
else
    diagnostics.max_abs_difference = max(abs(inMemory - reloaded));
end
end

function sha = localSha256File(path)
fid = fopen(path, 'rb');
if fid < 0
    error('a4:TopologyHashReadFailed', 'Cannot open topology CSV: %s', path);
end
cleaner = onCleanup(@() fclose(fid)); %#ok<NASGU>
bytes = fread(fid, Inf, '*uint8');

digest = java.security.MessageDigest.getInstance('SHA-256');
digest.update(bytes);
raw = typecast(digest.digest(), 'uint8');
sha = lower(reshape(dec2hex(raw, 2).', 1, []));
end
